# create-thumbs-lambda
AWS Lambda function that resizes images placed in a specific S3 Bucket and places the resized image into another S3 Bucket
